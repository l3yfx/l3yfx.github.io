import sys
import os
import string
import time

def stringValiadtor():
    s = "abc123"
    a, b, c, d, e = ([] for i in range(5))
    for i in s:
        a.append(i.isalnum())
        b.append(i.isalpha())
        c.append(i.isdigit())
        d.append(i.islower())
        e.append(i.isupper())

    print(any(a))
    print(any(b))
    print(any(c))
    print(any(d))
    print(any(e))

def textAlignment():
    c = 'H'
    thickness = 6
    for i in range(thickness):
        # print((c*i).rjust(thickness-1)+c+(c*i).ljust(thickness-1))
        print((c*i).rjust(thickness-1, '-'))
# textAlignment()

def matt():
    N, M = map(int, input().split(" "))
    pattern = '.|.'
    for i in range(N):
        if i < (N - 1) / 2:
            print((pattern * (2 * i + 1)).center(M , '-'))
        elif i == (N - 1) / 2:
            print("WELCOME".center(M, '-'))
        else:
            print((pattern * (2 * (N - i - 1) + 1)).center(M , '-'))
# matt()

def print_formatted(number):
    for i in range(1, number+1):
        number_hex = hex(i).split('x')[-1].upper()
        number_oct = oct(i).split('o')[-1]
        number_bin = bin(i).split('b')[-1]
        width = len(bin(number).split('b')[-1])
        print('{:>{w}d} {:>{w}} {:>{w}} {:>{w}}'.format(i, number_oct, number_hex, number_bin, w = width))

# print_formatted(99)
    
def print_rangoli(size):
    alpha = string.ascii_lowercase
    print(alpha)
# print_rangoli(5)

def listComprehension(x, y, z, n):
    list = [[i, j, k] for i in range(x+1) for j in range(y+1) for k in range(z+1) ]
    result = []
    print(list)
    for i in range(len(list)):
        if sum(list[i]) != n:
            result.append(list[i])
    
    print(result)
# listComprehension(1,1,1,2)    

def runnnerUp():
    a = [1,8,2,8,4,3,3,3,4,5,5]
    b = set(a)
    c = sorted(a)
    d = list(b)
    # print(b)
    # print(c)
    # print(d)
    d.remove(max(d))
    print(d)
    print(max(d))
    x = [i for i in a]
    print(x)
    minv = min(a)
    print(minv)
# runnnerUp()
def nestedList():
    list = []
    list.append([1,2])
    print(list)
# nestedList() 

def FTP():
    # a = 'a bc d'
    # c = ['a','b','c','d','e','f','g']
    # b = a.split()
    # while 'a' in c:
        # print('a')
    n = 1
    student_marks = {}
    for _ in range(n):
        name, *line = u'Krishna 67 68 69'.split()
        print(name)
        print(type(line))
        scores = list(map(float, line))
        student_marks[name] = scores
        student_marks['hahaha'] = "eh"
    # query_name = input()
    print(student_marks)
    # print(round(sum(student_marks['Krishna'])/len(student_marks['Krishna']), 2))
    print('%.2f' % float(sum(student_marks['Krishna'])/len(student_marks['Krishna'])))
# FTP()

def test():
    float theta = 180/lines*i
    x = sin(theta)
    y = cos(theta)

# class mastermind():
    # fundemental = essences, reality, innerbloom
    # reality = mindset, actions, reflection
    # mindset = mushin, try&error, reckless
    
def l3y(self):
    Essence
    	Nature
    Process
    	MasterMind
	        mushin
                Imperfection
	        Try&error
	            Problem solving
	                Breakdown challenge
	                    Making question
	                        Solved
	                    Try/Debug
	                        Solved
                Error handling
                    # Skateboarding concepts
                    Learn to fail.
                    CBS
	        Reckless
	            Feel/push the limit.
	            Used things in the way that are not used to be use.
	            Start simple, end epic.
    	# Analyze
    	# 	Breakdown target subject.
    	# Develop
    	# 	Learn the process.
    	# Refine
    	# 	BetterFasterStronger.
        Project
            l3yfx
                FXborg
            l3ysound
            l3yhack
    Innerbloom
        Visual
            Technical Engineering
                Alex Ma
                Ken Museth

def l3ysound(self):
    -Essence, process, vibe
    # from rough/skeleton to solid fine tune.
    # Destroy and recreate.(Bouncing clip)
    # can be feel but not heard.
    # ability to forsee.
    # find the process.
    # If the design takes too long to build, it's a bad design.
    Essence
        The same places  
    Process
        synth() = shape + timbre + pitch 
            Modulation + Automation + postProcessing
        flow() = motions + movement + tension
        score() = arrangement + layering + mixing
            Transient, parallel processing
        process = synth() + flow() + score() + sample()
        
        Sampled
            Sound sample
                ex. foley, bass
            Movement sample
                ex. wall fuck
                ex. dope beats
        Sound design(Synth)
            Timbre, shape, pitch
            Dope sounds
                Signal(Frequency, stereoImage) splitting/layering
                    Fx splitting/layering
                        Fx processing
                            Fx
                                Granular, reverb, grains
                                Combination
                    Signal flow
                        Automation
                        Push & limit
                Automation
                Motions around beats
        Flow design
            Motions, movement, tension
            # Sound & beats
            Motion
                MIDI
                Synth shape
                Fx Automation                    
                    Setup automation, then put fx on it.
                Transient
            Movement
                Horiontal Build/Layer around elements. Ex. Bass note based on drum beats.
                Transition
            Tension
                Vertical Build/Layer around elements. Ex. Add noise to fill spectrum.
            Dope flow
                BPM scope
                Catchy beats(Flow driven)
                Sharp transition    
    Vibe
    Inspired
        Skrillex redlips, trapdrum, kamakazi, panda
        Flume  Daze2200, wallfuck
def l3yhack(self):
    # cs
    cs() = computer, program, OS
    computer = Processor(instruction), RAM(data)
    program = "input -> system -> output"
    # coding
    coding() = programming + framework 
    programming = programming_language, logic, algorithm/data_structure
    programming_language = syntax, library, OOP(data, control_flow, organzation)
    # ps
    problem_solving() = framing, realization
    hack = cs() + coding() + problem_solving()    
    # garbageCollection(?)
    
    Essence
        
    Process
        Utilize Computer science to reach goals.
            Python
                Environment
                Coding
                Module
            # Data flow
                # Data structure
                # Data manipulation
                # Data organization
            # Algorithmic design
                # Design data flow to solve problems.
            # Organization
                # Custom Framework, Library
    Innerbloom
    
def l3yfx(self):
    3D_Concepts = CG_knowledge, software, workflow        
    3D = Modeling, animation, texture, lighting, rendering
    3D_FX = 3D.Data_manipulation
    
    VFX = FX() + Composition()
    
    -Essence, process, innerbloom
    
    Essence
        Nature inspired
    Process        
    # Technical
        Utilize Computer science to create 3D visual.
            Fundemental(Technical)
                def Foundation of 3D Computer graphic
                    Nature
                        Math/Physics
                            Noise
                            Motions
                    Computer science
                        CS
                            Multithread process
                                VEX
                        3D Computer graphic/theory
                            CG field
                                Mathmatics/Physics
                                algorithm                  
                            3D tech
                                Modeling
                                animation
                                Texturing
                                Lighting
                                Rendering
                                Compositing

            Process(Practice)    
                def Realization of 3D Computer graphic/theory
                    3D language/framwork/software
                        CG industry
                        Pipeline
                        Houdini(3D framework to user interdace)
                        	HDA
                        		User interface (Type properties)
                        			Action script(Python)
	                        Workflow(Using Houdini/Production efficieny)
	                            Expression
	                            Wrangle
	                            OP
	                            Python
                    3D FX R&D concepts - Harness the power of houdini -> Realize nature/imagination in a efficient way.
                        Data flow -> Controlling data is the key.
                            Data structure
                                Data types
                                    Low-lev
                                        float, int, array, vector, matrix, string, dictionary
                                    High-lev
                                        Geometry
											Attributes
                                    			Context
                                       				Point,vertex,primitive,detail                                            
                                    			Reserved/Custom attributes
                                        			P,Normal,UVs,V,pscale
                                        Primitive
                                            Bezier/NURBS
                                            Volume
                                                Scalar field(density)
                                                Sign distance(SDF)
                                                Vector field
                                            PointCloud
                            Data manipulation
                                Caculation
                                    Math
                                        Cross product
                                Functions                                       
                                    Operater
                                        SOP, VOP, POP, DOP(Solver)
                                    Low-lev
                                        nearpoint, primuv, minpos, length,....
                                    High-lev
                                        Particle, pyro, flip, vellum, SDF,....
                                    Noise
                                        Curlnoise, turbulentnoise, voronoise,....
                                    Custom function
                                        Sorting
                                        Filtering                                    
                                Operation
                                    Conditional(Constraint)
                                        Grouping
                                            Selection
                                            Pattern
                                            Expression
                                    Loop
                                    Copy/Instancing
                                    Ramp/fit
                                    AttributeTransfer
                                        UV technique
                                Network
	                                data stream(Proceduralism)
	                                    Parameter/Channel Referencing
	                                    	ch()
                                            point(), detail()
	                                    Parameter/Channel expression
	                                    	Global/Local/Geo/Environment variable
		                                        Expression function
		                                        		If,abs
                                        		HScript expression
                                        			$F / 10
		                                        Vex expression
			                                        Global
			                                        	@Time.@Frame
		                                        	Local
		                                        		@ptnum
			                                        Geo attributes  
			                                        	@width                          
                            Data organization
                                File system
                                    Cache to disk
                                Compile blocks
                                Pipeline
                        Algorithmic design
                            Constructing data flow for specific fx in a algorithmic way.
                                    Utilize each data structures features to write algorithm for specific fx.
                                        Motion (Effect based)                                        
                                            Dimensions
                                                Proceduralism CRUD 3D data
                                                Simulation Dynamics 3D data
                                            Context
                                            # Building blocks
                                                SOP
                                                    Surface operation
                                                        Geometry computation
                                                    Attribute operation
                                                DOP
                                                    Dynamics operation
                                        Time (Horizontal based)
                                            Frame control(timeshift)
                                        Layer (Vertical based)
                            Implement realWorld/algorithmic/mathmatical/physics concepts/papers/theory for R&D process.
                                Iterative, Fractual
                            Refine data flow process for performance optimaization
                        Organzation
                            Create digital asset for speeding up workflow.
                            Create tool/plugin for optimize workflow.
                            
                    3D rigging concepts
                    	Bones placing
                    	IK/FK system
                    	Proxy geometry
                    3D Lighting concepts
                    3D Shading concepts
                        Procedual shading
                            Principled shader
                            Displacement
                            Micro surface
                        Create/assign Material
                        Apply map
                            Texture
                            Normal
                            Bump
                        White papers
                    3D Rendering concepts
                    3D Compositing concepts 
                        Camera tracking
                            movement matching
                        Rotoscoping
                            Maskking objects
                        Look-matching
                            Lighting
                                Shadow
                            Color correction
                                Color matching
                            Depth of field
                                Focus point
                            Grains
                                Film grains/noise
            # def FX R&D
            	# FX = CS + R&D + Look_dev
                # FX R&D(Practice)
                #     FX() + Flow() + Score()
                #     FX() = Basic_idea + Advance_development
                #     Flow() = Combiine_FX(Motion, movement, tension)
                #     Score() = Look_dev()
        Innerbloom
        
    //reference
        # Artist
        james turrell
        urs fischer
        # Tutor
        Adam Swaab
        
    // Learn
        SOP/Primitive
        FX/Simulation
        Shading
        Lightiing
        Rendering
        Composting
    //
        Theory
        Realization of theory
Class FX():
    def __init__(self):
        pass
    def WireCrawlingMesh(self):
        # Point trails crawing around surface without intersection.
        # *POPinteract
    def MeshSurfaceScan:
        # Circle minpos to sphere.
    def knitting:

        
        