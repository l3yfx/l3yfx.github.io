import sys
from itertools import product, permutations
import cmath
import time
import os
import subprocess
import datetime

def iter_product():
    # i_1 = input()
    # i_2 = input()
    a = input().split()
    b = input().split()
    a = list(map(int, a))
    # c = list(int(i) for i in b) -> list comprehension
    # print(c)
    # t = map(int, b)
    # print(t)
    b = list(map(int, b))
    # print(a)
    int_list = list(product(a, b))
    print(*int_list)
    print(int_list)
    for _ in int_list:
        print(_, end = " ")
def iter_permutation():
    # Get input.
    a = input()
    in_string = a.split()[0]
    in_size = a.split()[1]
    per = list(permutations(in_string, int(in_size)))
    # method 1
    # for i in range(len(per)):
        # out = ""
        # for j in range(len(per[i])):
            # out += per[i][j]
        # print(out)
    # method2
    # for i in per:
        # print("".join(i))
    [print("".join(i)) for i in per]
# iter_permutation()
def polar_coordinate():
    z = input()
    print(complex(z))
    out1 = cmath.phase(complex(z)) #phase
    out2 = cmath.abs(complex(z)) #modulus
    print("{}\n{}".format(out1, out2))
# polar_coordinate()
def set_distinct_height():
    # n= input()
    # array = list(input().split()) #no need to list converter, .split function already did it.
    array = map(int,input().split())
    distinct_array = set(array)
    average_height = round(sum(distinct_array)/len(distinct_array), 3)
    print(average_height)
# set_distinct_height()  
def set_differnce_set_list():
    a = input()
    a_list = set(input().split())
    b = input()
    b_list = set(input().split())
    out = []
    dif_a = a_list.difference(b_list)
    dif_b = b_list.difference(a_list)
    for i in dif_a:
        out.append(i)
    for i in dif_b:
        out.append(i)
    # print(type(out.sort()))
    out.sort()
    print(out)
    [print(i) for i in out]
    
def set_differnce_set():
    a = input()
    a_list = set(input().split())
    b = input()
    b_list = set(input().split())
    out = []
    dif = a_list.difference(b_list)
    # dif2 = b_list.difference(a_list)
    # dif.update({8,9})
    print(dif)
    # print(dif2)
    dif.update(b_list.difference(a_list))
    # print(dif)
    # print(type(sorted(dif)))
    out = sorted(dif)
    print(out)
    # print(type(dif.update(dif2)))
    print(type(b_list.difference(a_list)))
    [print(i) for i in out]    
# set_differnce_set()
def f_test(e, li=[]):
    print(e)
    li.append(e)
    print(li)
# f_test(1,2)
# f_test(2)
def set_noidea():
    i_0 = "3 2"
    i_1 = "1 5 3"
    i_2 = "3 1"
    i_3 = "5 7"
    start_time = time.time()
    print(start_time)
    happiness = 0
    # List traverse
    # for i in i_1.split():
        # if i in i_2.split():
            # happiness += 1
        # if i in i_3.split():
            # happiness -= 1
    # print(happiness)
    # boolean add
    # t = True
    # f = True
    # print(t+f)   
# for i in i_1.split():
    # a = i in set(i_2.split())
    # b = i in set(i_3.split())
    # print(a-b)
    like = i_2.split()
    dislike = i_3.split()
    # o = sum((i in like) - (i in dislike) for i in i_1.split())
    # print(o)
    t = set(map(int,i_1.split()))
    t2 = set(list(map(int,i_1.split())))
    print(t)
    print(t2)
    print(time.time())
    print("--- %s seconds ---" % (time.time() - start_time))
# set_noidea()
# count = 5
def namespace():
    def some_method():
        global count
        count = count + 1
        print(count)
    print(count)
    some_method()
# namespace()
class test_class:
    """Test class"""
    c_variable = "test_variable"
    def __init__(self, first_name, last_name):
        self.first_name = first_name
        self.last_name = last_name
    def display(self):
        print("this is {}, {}".format(self.first_name, self.last_name))
# cl = test_class("Stveee", "DEVE")
# cl.display()
# print(cl.c_variable)
def set_distinct_stamp():
    # a = "a b c d e f g"
    # b = set(input().split()[1:])
    # b = set(a.split()[1:])
    # print(len(b)) 
    inp = [input() for i in range(int(input()))]
    country = set(inp)
    print(len(country))
# set_distinct_stamp()
def sue_reboot():
    t = 3
    t2 = 10000
    os.system("adb logcat")
    # logcat = subprocess.Popen("adb devices", stdout=subprocess.PIPE)
    print("hh")
    subprocess.Popen("adb devices")
    line = logcat.stdout.readline()
    print(line)

    while t:
        print(logcat.returncode)
        t -= 1
        time.sleep(1)
        if poll is None:
            pass
            print("Logcat still running!!!")
        else:
            print("Logcat stoped!!!")
    logcat.kill()
    poll = logcat.poll()
    print(poll)
    while t2:
        print(poll)
        t2 -= 1    
    stdoutdata, stderrdata = logcat.communicate()
    print(logcat.returncode)
# sue_reboot()
def PIPE_learn():
    print("what's your name?")
    for name in iter(sys.stdin.readline, ''):
        name = name[:-1]
        if name == "exit":
            break
        print("Well how do you do {0}?".format(name))
        print("what's your name?")
# PIPE_learn()  
def subprocess_test():
    # r = subprocess.call("dir", shell = True)
    # subprocess.call("adb devices")
    # print(r)
    # output = subprocess.check_output("dir", shell = True)
    # print(output)
    # process = subprocess.Popen("adb devices", stdout = subprocess.PIPE)
    # subprocess.Popen("adb devices")
    # subprocess.Popen("adb devices", shell = True)
    subprocess.Popen("adb devices", shell = True, stdout = subprocess.PIPE)
    # process.kill()
    # return_code = process.poll()
    # pid = process.pid
    # process.communicate()
    output = process.communicate()
    print(output)    
    print(return_code)
    print(pid)
    stdo = process.stdout.read()
    print(stdo)
# subprocess_test()
def subprocess_test_for_boottime():
    # p = subprocess.Popen("adb logcat", shell = True, stdout = subprocess.PIPE)
    p = subprocess.Popen("adb logcat", stdout = subprocess.PIPE)
    time.sleep(3)
    print(p.pid)
    p.poll()
    print(p.returncode)
    p.kill()
    time.sleep(3)
    p.poll()
    print(p.pid)
    print(p.returncode)
# subprocess_test_for_boottime()
def subprocess_call_blocking():
    subprocess.call('dir', shell = True)
    t = 10
    while t:
        time.sleep(1)
        print("testing")
        t -= 1
# subprocess_call_blocking()
def subprocess_check_bootTime():
    t = 0
    # Spawn a process for adb logcat.
    logcat = subprocess.Popen(["adb", "logcat"],
                                stderr = subprocess.PIPE, 
                                stdout = subprocess.PIPE)
    # logcat = subprocess.call("adb logcat")
    # Check adb logcat end or not.
    # print("Reboot")
    # time.sleep(3)
    subprocess.Popen("adb reboot")    
    ts1 = datetime.datetime.now()
    print(ts1)
    while not t:
        line = str(logcat.stdout.readline())
        # line = str(logcat.communicate())
        # print(line)
        if "ServiceManager: service 'vold' died" in line:
            print(line)
            print("match")
            ts2 = datetime.datetime.now()
            print(ts2)
            print(ts2-ts1)
            break            
        # print(logcat.poll())
        # if(str(logcat.poll()) == "0"):
            # ts2 = datetime.datetime.now()
            # print(ts2)
            # print(ts2-ts1)
            # break
            
        # time.sleep(1)
        # t += 1
    # logcat.kill()
    # time.sleep(1)
    # print(logcat.poll())
    
    #Final
    # while True:
        # line = logcat.stdout.readline()
        # print(line)
        # if str(logcat.poll()) == "0":
            # print("Rebooting start!!!")
            # break
    
    # some practice.
    # while logcat.poll():
        # line = logcat.stdout.readline()
        # print(line)
        # print(logcat.poll())
        # if logcat.poll():
            # print("Rebooting start !!!!!!")
            # break
            
        # time.sleep(1)
        # if line != "b''":
            # print(line)
            # print("not yet reboot..")
        # else:
            # print("reboot start..")
            # break
        # time.sleep(1)
        # logcat.poll()
        # print(logcat.pid)
        # logcat_status = logcat.poll()
        # print(logcat_status)
        # if logcat_status == 1:
            # print("Logcat process has ended, which means device started rebooting..")
            # break
    print("Follow steps...")
# subprocess_check_bootTime()    
def read_test():
    f = open("vim.txt")
    # line = f.readline()
    # print(line)
    line = f.readlines()
    print(line)
    while line:
        print(line)        
# read_test()    
# List comprehension print()
def print_with_listConprehension():
    [print(i) for i in range(10)]
def input_comprehension():
    a = input("\n\nenter\n\n")
    print()
    int_list = [int(i) for i in str_list]
    print(int_list)
    for i in str_list:
        print(i)
        print(type(i))
def fib_sequencer_iterative(n):
    #First try
    # if n >=0 :
        # i = 0
        # j = 1
        # temp = 0
        # for _ in range(n):
            # if _ == 0:
                # print(i, end = " ")
            # elif _ == 1:
                # print(j, end = " ")
            # else:
                # temp = i + j
                # i = j
                # j = temp
                # print(temp, end = " ")
    # Secon try
    if n >= 0:
        a, b = 0, 1
        for _i in range(n):
            a = b
            b = a+b           
            print(a, end = " ")
# fib_sequencer(10)
def f(n):
    a, b = 0, 1
    for i in range(0, n):
        a, b = b, a + b
        # return a    
    return a
# print(f(0))
# print(f(1))
tt = 0
def fib_sequencer_recursive(n):
    global tt
    tt += 1
    if n >= 0:
        if n == 1:
            return 1
        elif n == 0:
            return 0
        else:
            return fib_sequencer_recursive(n-1) + fib_sequencer_recursive(n-2)
# print(fib_sequencer_recursive(3))
# print(tt)
# 10
# 9 8
# 8 7 7 6
# 7 6 6 5 6 5 5 4
# .....Exponential -> 2^n
# 3
# 2 1
# 1 0 0
# for i in range(19):
    # print(fib_sequencer_recursive(i), end=' ')
def set_countSumOfArray():
    # Sort input.
    member_num = int(input())
    member = set(map(int, input().split()))
    commands = [input() for i in range(int(input()))]
    # print(member_num)
    # print(member)
    # print(commands)
    for i in commands:
        if i.split()[0] == "pop":
            member.pop()
        if i.split()[0] == "remove" or i.split()[0] == "discard":
            member.discard(int(i.split()[1]))
        # if i.split()[0] == "discard": 
            # member.discard(i.split()[1])
    print(sum(member))
# set_countSumOfArray()    
    
def set_union():
    eng_num = input()
    eng_roll= set(input().split())
    fre_num = input()
    fre_roll = set(input().split())
    t = eng_roll.union(fre_roll)
    print(t)
# set_union()
def set_intersection():
    e_num = input()
    # Convert a string input into list
    e_roll = set(input().split())
    f_num = input()
    f_roll = set(input().split())
    intersect = e_roll.intersection(f_roll)
    print(len(intersect))
def set_difference():
    _,e_roll = input(), set(input().split())
    _,f_roll = input(), set(input().split())
    print(len(e_roll.difference(f_roll)))
def set_symmetric_difference():
    _,e_roll = input(), set(input().split())
    _,f_roll = input(), set(input().split())
    print(len(e_roll.symmetric_difference(f_roll)))
def set_mutation():
    # Target set (a) to be mutated.
    _,a = input(), set(map(int, input().split()))
    # Others sets as mutator.
    for _ in range(int(input())):
        c = input().split()[0]
        s = set(map(int, input().split()))
        if c == "intersection_update":
            a.intersection_update(s)
        elif c == "update":
            a.update(s)
        elif c == "symmetric_difference_update":
            a.symmetric_difference_update(s)
        elif c == "difference_update":
            a.difference_update(s)
    print(sum(a))
def set_captainroom():
    # Get unique number from list
    _, checkin = input(), input().split()
    
# def vim_test():
  #print(__name__)
  #print(list(product([1,2], repeat = 2)))
  #print(list(product([1,2], "a")))
  # print(list([1,2], repeat = 2)) 
# vim_test()
# a = product([1,2,3], repeat = 2)
# print(list(a))