class FX_Res
    def SOP
        Geometry component
            Point,vertex,primitive,detail  
                Attributes
                    Context
                        Point,vertex,primitive,detail                                            
                    Reserved/Custom attributes
                        P,Normal,UVs,V,pscale
                Primitive
                    Bezier/NURBS
                    Volume
                        Scalar field(density)
                        Sign distance(SDF)
                        Vector field
                    PointCloud
    def VDB
        Theory
            Efficient memory and fast data access.
            No topology restrictions.
        Context
            *Manipulate voxel data to create 3D mesh(fog,smoke,fire,fluid,fracture,meshing)
                # vdbAnalysis(gradient,cpt,.....)                  
            *Store data in voxel to tansfer data.
                # attributeFromVolume
        Utilization
            Scalar field(density)
                Volumemetric modeling
            Signed distance field(SDF)
                Surface modeling
            Vector field
                Vel, Force
        Function
            VolumeSample/VolumeSamplev
            Volumepostoindex/Volumeindextopos
            attributeFromVolume
            vdbAnalysis
                Gradient
                CPT
            Volume Vop
            vdbactivate
            vdbAdvect
            vdbSmooth
            SDF collider        
        Visualizer
            Volume visualization (For density overview)
            Volume Trail (For vel direction)
            vdbvisualizertree
            volumeslice
        Debug
            addpoint/setpoint attribute
        Rendering
            Mantra rendering Isosurface(SDF volume)
        # VDB_Meshing
            VDB vs Houdini standard volume
                VDBFrom polygon
                    Exterior/Interior band -> Data caculation efficiency, "Sparse data structure".
                    Surface attribute -> transfer attribute to volume data
                VDBSmoothSDB -> Smoothing surface with various algorithm.
                VDBCombine -> Boolean operation
                Houdini standard volume has exclusive toolset/openCL function.
            Volume boolean
                Volume modeling
                    Voxel size decrease to half of the smallest feature of geometry.        
        # VDB_VectorField
            SDF collision
    def POP
		Sorce(Emitter)
			Birth
				Impulse
				Constant
			Life
			Emission attribute
                velocity
        Object
		Operation(Force)
            pre-solve
            post-solve
                Attract
                Interact
                Wind/Force
                Drag
                POP kill
                POP Sprite
                POP VOP
                Group
                Color
        Solver
    def DOP
        object, source, solver and force.
        
        relationships (Adjust relationships to optimize the simulation)
        
class Render_Res
    def redshift
        Progressive vs Bucket mode
			Progressive rendering
				fast feedback when shaders, meshes or lights are edited.
			Bucket mode 
				Recommended instead of progressive mode for final renders.
		Fixed rate vs adaptive sampling
			Fixed rate
				Shooting the same number of primary rays per pixel
			adaptive sampling
				Unified sampling
					Detects the parts of the image that are noisy/jaggy and automatically adjusts the number of primary rays for each pixel. This can speed up rendering considerably.
		

class FX_Dev
    Mindset = hard coded vs tool usage
    def SOP
        Surface attribute manipulation algorithms.
            UVXform
            NoiseOffset
    # def Growth
    # 1 way transform.
        # Copy&Instance
            # Dev_Crassula
        # Noise + @P transform
            # Dev_SnakeIsland
        # Move & Trail
            # Project_NikeFlyknit
        # VDB modeling/advecting
            # Dev_Organic
    # def Morph
    # 2 ways transform.          
        # UV xform 
                # Dev_LineMorph
                # Dev_Venus
        # @P mix function
            # Dev_Knitting
    # def Magic
        # Vector field Vel & SDF
            # Dev_MagicFluid
        # POP Force
            # Dev_Cradence

class FX_Project
    def FxBorg
        Create FxBorg with dev effects.
            3D model rigging/animating
            FX develop
            Rendering(Houdini x Redshift)
            Compositing(Fusion)
            Color grading(Resolve)
            Camera tracking(Fusion)
        fxb_1
            FxBorg Arm replacemnt
                -Watercooling tube
                    Straight/Curl
                -Wireframe mechanic
                -Lab particles test tube
                -Hollow geo effect
            Learn topics
                -Rigging
                    Body rigging
                -Basic redshift setup
                    Lighting
                        RSLight,RSDome(HDRI)
                    Shading
                        MAT, material builder, OBJ spare parameter
                    Render setting
                        Camera,ROP
                -SOP operation
                    point deform function
                    Attribute transfer technique
                -Volume meshing
                    vdbfrompolygon
                    Volume scatter
                    vdb smooth
                -Compositing
                    Davinci resolve image edit.
                    Colorgrading
        fxb_2
            FXborg Leg replacemnt
                # -Recursive subdivided mesh
                -Volume SDF flow
                -Volume trail
                -Crawling mamba mechanic
            Scenes
                Still
                    SDFlowWire + Python
                        Close shot x2
                        vfx shot x1
                Anima
                    SDFFlowParticle(Surface) + SDFFlowParticle(Around) + Python
                        vfx shot x1
            Learn topics
                -SOP operation
                    Sweep
                    CopytoPoint instancing
                        @Normal, @Up
                    Group with pattern
                -Volume operation
                        VolumeTrail
                        SDF flow
                -POP operation
                    advectbyvolume
                # -FOR-LOOP recursive/iterative function uterlization
                -Advanced Redshift Shading     
                    Paticle rendering
                    Strands rendering
                    Apply texture/bump
        fxb_3
            FXborg arm replacement
                -Nano tech(Paticle)
            Learn topics
                -SOP operation
                    1. Edge scatter POP
                    2. XForm surface attribute
                Redshift
                    1. RS material blending
        fxb_4
            FXborg leg replacement
                -Cmex
            Learn topics
                1. Rmesh with @targetmesgsize
                2. Walkby trigger
                3. Extrude scale variation
                4. Extrude direction variatio
        fxb_5
            FXborg hand(palm) replacement
                -Crassula